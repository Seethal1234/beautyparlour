import React, { useEffect, useState } from "react";
import { useParams } from 'react-router-dom'
import axios from 'axios';
import '../pages/Productdetails.css'
export default function Productdetails() {

  const {id}= useParams()  //destructure
  
 
  const[productdetail,setProductdetail] = useState([]);
  const url =`http://localhost:2000/product/productdetails/${id}`
  console.log(productdetail);

  useEffect(()=>{
    axios.get(url).then((response)=>{
      setProductdetail(response.data.Product_details)
      console.log(response.data.Product_details);
    })
  },[])
  
  return (
    <>
      <div class="how-section1">
        <div class="row">
          <div class="col-md-6 how-img">
            <img
              src={`/images/${productdetail.image}`}
              class="rounded-circle img-fluid"
              alt="cccc"
              height="250px"
              width="250px"
            />
          </div>
         
          <div class="col-md-6">
         
            <h4>{productdetail.productname}</h4>
            <h4 class="subheading">
              {productdetail.category}
            </h4>
            <p class="text-muted">
              {productdetail.description}
            </p>
            <p>{productdetail.price}</p>

            <a href={`/editproduct/${productdetail._id}`} class="btn btn-warning btn-lg active" role="button" aria-pressed="true">EDIT</a>
            <a href="" class="btn btn-warning  btn-lg active" role="button" aria-pressed="true" id="deletebtn">DELETE</a>
          </div>



         

   
        </div>
     
      </div>
    </>
  );
}
