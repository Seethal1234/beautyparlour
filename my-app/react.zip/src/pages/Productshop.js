import React from "react";
import './Productshop.css'
import Menu from '../components/Menu'
import Viewproduct from "../components/Viewproduct";
export default function Productshop() {
  return (
    <>
     <Menu />
     <Viewproduct/>
    </>
  );
}
