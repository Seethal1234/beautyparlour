import React from 'react'

export default function Smenu() {
  return (
    <>
       <div class="parent">
       <div>
        <h1 id="servicemenu">SERVICE MENU</h1>
        <p id="servicemenu1">We enhance individial beauty with state-of-the-art technologies and personalized service.<br></br> Our professional team is ready to provide the greatest service <br></br>you’ve ever had.</p>
       </div>
    </div>
    
    </>
  )
}
