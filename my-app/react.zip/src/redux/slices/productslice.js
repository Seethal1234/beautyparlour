import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

const initialState = {
  viewproduct: [],
  loading: false,
  error: false,
};

const viewproduct_url = "http://localhost:2000/user/view-product";

export const view_product = createAsyncThunk("viewproduct", async () => {
  const response = await fetch(viewproduct_url);
  return response.json();
});

const productslice = createSlice({
  name: "productview",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(view_product.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(view_product.fulfilled, (state,action) => {
      state.loading = false;
      state.viewproduct=action.payload.product_details
    });
    builder.addCase(view_product.rejected, (state) => {
      state.loading = false;
      state.error=true
    });
  },
});

export default productslice.reducer;
