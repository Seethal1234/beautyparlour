import { configureStore } from "@reduxjs/toolkit";
import productviewreducer from '../slices/productslice'
export const  store = configureStore({
reducer : {
    productview : productviewreducer
}
})